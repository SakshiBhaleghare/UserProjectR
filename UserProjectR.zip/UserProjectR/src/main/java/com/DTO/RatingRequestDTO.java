package com.DTO;

import lombok.Data;

@Data
public class RatingRequestDTO {

	private Long storeId;
	private int ratingValue;
}
