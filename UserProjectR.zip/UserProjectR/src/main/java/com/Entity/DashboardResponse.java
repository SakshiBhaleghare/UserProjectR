package com.Entity;

import java.util.List;

import com.DTO.UserDTO;

public class DashboardResponse {

	public DashboardResponse(String name, double average, List<UserDTO> userRatings2) {
		// TODO Auto-generated constructor stub
	}
	private String storeName;
	private double averageRating;
	private List<UserDTO> userRatings;
}
