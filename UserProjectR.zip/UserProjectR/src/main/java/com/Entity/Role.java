package com.Entity;

import javax.persistence.Entity;

@Entity
public enum Role {

	SYSTEM_ADMIN, NORMAL_USER, STORE_OWNER
}
